function launch(module) {
  const log = document.getElementById('log');
  const time = new Date().toLocaleTimeString();
  log.innerHTML = `[${time}] ✅ ${module} ativado com sucesso.<br>` + log.innerHTML;
}